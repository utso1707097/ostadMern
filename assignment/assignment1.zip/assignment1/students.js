let studentList = [
    {name:"labib",roll:1707061},
    {name:"nayem",roll:1707064},
    {name:"sadaf",roll:1707066},
    {name:"argha",roll:1707069},
    {name:"shihab",roll:1707073},
    {name:"osman",roll:1707076},
    {name:"nafee",roll:1707077},
    {name:"munna",roll:1707081},
    {name:"mustafiz",roll:1707083},
    {name:"kaab",roll:1707084},
    {name:"nazrul",roll:1707086},
    {name:"mishu",roll:1707093},
    {name:"adel",roll:1707094},
    {name:"rakib",roll:1707095},
    {name:"rocky",roll:1707096},
    {name:"utso",roll:1707097},
    {name:"masum",roll:1707098},
    {name:"dipta",roll:1707099},
    {name:"mumu",roll:17070100}
]

export {studentList};